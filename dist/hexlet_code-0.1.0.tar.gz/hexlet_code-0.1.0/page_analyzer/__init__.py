from page_analyzer.app import app
__all__ = ('app', )
